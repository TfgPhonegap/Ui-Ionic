# ionic-bower

If you wish to install the latest stable version, simply `bower install driftyco/ionic-bower`

If you wish to install the latest nightly release, `bower install driftyco/ionic-bower#master`
