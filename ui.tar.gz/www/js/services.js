angular.module('starter.services', [])

/**
 * A simple example service that returns some data.
 */
.factory('Friends', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var friends = [
    { id: 0, name: 'Scruff McGruff', description:'Yeah dude!!' },
    { id: 1, name: 'G.I. Joe', description:'Im GI JOE' },
    { id: 2, name: 'Miss Frizzle', description:'surffing' },
    { id: 3, name: 'Ash Ketchum', description:'Bussy' }
  ];

  return {
    all: function() {
      return friends;
    },
    get: function(friendId) {
      // Simple index lookup
      return friends[friendId];
    }
  }
})

.factory('LeftPanel', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var items = [
    { title: "Home", link:"#/tab", type:"item item-icon-left", icon:"icon ion-home"},
    { title: "Ubicacions", link:"#/tab/friends", type:"item item-icon-left", icon:"icon ion-android-location"},
    { title: "Acces", link:"#/tab/friends", type:"item item-icon-left", icon:"icon ion-key"},
    { title: "Friends", link:"#/tab/friends", type:"item item-icon-left", icon:"icon ion-android-friends"},
    { title: "Settings", link:"#/tab/friends", type:"item item-icon-left", icon:"icon ion-gear-a"},
    { title: "Pull to ref", link:"#/tab/pullToRefresh", type:"item item-icon-left", icon:"icon ion-loading-b"},
    { title: "Infinite", link:"#/tab/infinite", type:"item item-icon-left", icon:"icon ion-loading-b"}
  ];

  return {
    all: function() {
      return items;
    },
    get: function(friendId) {
      // Simple index lookup
      return items[title];
    }
  }
});
